#!/usr/bin/env python3
import sys
from simplecrypt import encrypt, decrypt
from base64 import b64encode, b64decode
from getpass import getpass

password = getpass() #Will prompt you to enter any password you would like
message = "" #Enter any message you would like between the quotes

cipher = encrypt(password, message)
encoded_cipher = b64encode(cipher)
print(encoded_cipher)
