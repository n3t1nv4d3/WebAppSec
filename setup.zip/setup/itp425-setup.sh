#!/usr/bin/env bash
################################################
# Setup script for ITP425 - Web App Security
# Usage: exec bash itp425-setup.sh 
# Last Updated 08/13/2022
# Designed for Kali Linux 2022.2 fresh install
################################################
mydir=`pwd`
user=`whoami`
echo
echo "Getting System Ready for ITP425 - Web Application Security"
echo
echo
echo "... Begin Transmission ... "
echo
echo
echo
echo "Phase 1: Performing System Enhancements ..."
echo
sudo apt update && sudo apt -y upgrade && sudo apt -y full-upgrade && sudo apt clean && sudo apt -y autoremove
sudo apt install -y burpsuite zaproxy
mkdir /home/$user/Desktop/wordlists
mv *.txt /home/$user/Desktop/wordlists/
echo
echo "...System at Optimal Settings..."
echo
echo "Phase 2: Setting up Background, Panel and Aliases ..."
echo
echo "alias updat3=''sudo apt update && sudo apt -y upgrade && sudo apt -y full-upgrade && sudo apt clean && sudo apt -y autoremove''" >> /home/$user/.zshrc
echo "alias pserver=''sudo python3 -m http.server ''" >> /home/$user/.zshrc
echo "alias shell=''sudo rlwrap nc -lvnp ''" >> /home/$user/.zshrc
echo
cd $mydir
mv wstg-v4.2.pdf /home/$user/Desktop/wstg-v4.2.pdf
mv usc-itp.png /home/$user/Pictures/
xfconf-query --channel xfce4-desktop --property /backdrop/screen0/monitorrdp0/workspace0/last-image --set /home/$user/Pictures/usc-itp.png
xfce4-panel --add=separator
xfce4-panel --add=launcher /usr/share/applications/firefox-esr.desktop
xfce4-panel --add=launcher /usr/share/applications/kali-burpsuite.desktop
xfce4-panel --add=launcher /usr/share/applications/kali-zaproxy.desktop
xfce4-panel --add=launcher /usr/share/applications/xfce-text-editor.desktop
xfce4-panel --add=launcher /usr/share/applications/xfce4-screenshooter.desktop
echo
source /home/$user/.zshrc > /dev/null 2>&1
echo
sleep 3
echo "...Aliases Added to ~/.zshrc..."
echo
echo
sleep 3
echo "Phase 3: Setting up DNS ..."
echo
sudo apt-get install bind9 bind9utils bind9-doc dnsutils -y
echo
sudo mv forward.itp425.* /etc/bind/
sudo mv rev.* /etc/bind/
sudo mv named.conf.local /etc/bind/
echo
# Turning on services
sudo systemctl start named
# Enable a few for runtimes 3 4 5
sudo update-rc.d named enable
echo "...DNS Settings Configured..."
echo
echo
echo "Phase 4: Installing Tools to makes life easier ..."
echo
cd $mydir
sudo mv -f testssl /opt
sudo chmod -R 755 /opt/testssl
sudo mv *.py /opt
echo
echo
python3 -m pip install --upgrade pip
pip install simple-crypt
pip install pyDes
pip install pymysql
pip install pwntools
sudo apt clean && sudo apt -y autoremove
echo
sleep 2
cd $mydir
# Getting more wordlists
cd /usr/share/wordlists
sudo git clone https://github.com/danielmiessler/SecLists.git 
echo
# Getting ysoserial
cd /opt
sudo mkdir ysoserial && cd $_
sudo wget https://jitpack.io/com/github/frohoff/ysoserial/master-SNAPSHOT/ysoserial-master-SNAPSHOT.jar -O ysoserial.jar
echo
# Getting PayloadsAllTheThings repo
cd /opt
sudo git clone https://github.com/swisskyrepo/PayloadsAllTheThings.git 
echo
# Installing some great CheatSheets and info
cd /opt
sudo git clone https://github.com/The-Art-of-Hacking/h4cker.git
echo
echo "...All toolz are installed..."
sleep 5
# Final confirmation
echo
echo "
All tools, apps, and containers have been installed and setup.
--------------------------------------------------------------

Try these new shortcuts now:

+---------+-----------------------------------------------------------+
| Command | Purpose                                                   |
+---------+-----------------------------------------------------------+
|  updat3 | Performs a system full-upgrade and removes older packages |
+---------+-----------------------------------------------------------+
| pserver | Starts a Python3 http listerner to transfer payloads, just|
|         | enter a random port number to use (ex. 99)                |
+---------+-----------------------------------------------------------+
|  shell  | Starts an NetCat listerner waiting for a reverse shell,   |
|         | enter a port to list on (ex. 1337)                        |
+---------+-----------------------------------------------------------+

*if they don't work, run this cmd: \"source ~/.zshrc\" and try them again.* 

---------------------------------------------------------------------
"
echo
echo
# Clean up and re-running services
source /home/$user/.zshrc > /dev/null 2>&1
cd /home/$user/
sudo rm -r /home/$user/Desktop/setup.zip
sudo rm -r $mydir
echo
echo "Enhancements Successfully Installed"
echo
echo
echo "Rebooting the system to wrap up installation. End Transmission."
sleep 10
reboot