#!/usr/bin/env python3
import sys
from simplecrypt import encrypt, decrypt
from base64 import b64encode, b64decode
from getpass import getpass

password = getpass() #Will prompt for password, use the discovered password when asked
encoded_cipher = "" #Place the final base64 string here between quotes

cipher = b64decode(encoded_cipher)
plaintext = decrypt(password, cipher)
print(plaintext)
