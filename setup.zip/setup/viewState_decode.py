#!/usr/bin/env python3
import pyDes, hmac
from base64 import b64decode, b64encode
from hashlib import sha1

print("")
key = b64decode('KEY') #replace KEY with secret key base64 value
print("Decoded base64 value: ",key)
print("")
java_faces = "java.faces.ViewState" #replace java.faces.ViewState with ViewState value
print("Current value of java_faces: ",java_faces)
print("")

def decrypt_view_state(view_state):
    #To use pyDes we need the following info:DES uses ECB mode and include padding method
    obj = pyDes.des(key, pyDes.ECB, padmode=pyDes.PAD_PKCS5)
    #decode the ViewState value
    view_state = b64decode(view_state)
    #include padding (NULL \x00) byte
    view_state = view_state + b'\x00\x00\x00\x00'
    #character lenght of ViewState
    print(len(view_state))
    #decrypt ViewState
    dec = obj.decrypt(view_state)
    return dec

print("Here is the cleartext value of java_faces: ",(decrypt_view_state(java_faces)))
print("")
print("This is the java deserialization value we are looking for: ",(b64encode(decrypt_view_state(java_faces))))
